package io.qameta.allure.junit5.features;

import org.junit.jupiter.api.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class PassedTests {

    @Test
    void first() {
    }

    @Test
    void second() {
    }

    @Test
    void third() {
    }

}
