package io.qameta.allure.spock

import spock.lang.Specification

/**
 * Created on 16.06.2017
 *
 * @author Yuri Kudryavtsev
 *         skype: yuri.kudryavtsev.indeed
 *         email: yuri.kudryavtsev@indeed-id.com
 */

class SpockTest extends Specification {
    def "Example of Spock Test"() {
        expect:
        true
    }
}
