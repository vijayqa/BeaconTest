package io.qameta.allure.testng;

import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class TestNgTest {

    @Test
    public void testNgTest() throws Exception {
    }
}
