package io.qameta.allure.junit5;

import org.junit.jupiter.api.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class Junit5Test {

    @Test
    void junit5Test() {
    }
}
