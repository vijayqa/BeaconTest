import org.junit.Test;

/**
 * @author jkt on 15.08.17.
 */
public class SampleTestInDefaultPackage {

    @Test
    public void testMethod() {

    }
}
