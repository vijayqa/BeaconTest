package io.qameta.allure.junit4.samples;

import org.junit.Ignore;
import org.junit.Test;

/**
 * @author gladnik (Nikolai Gladkov)
 */
@Ignore
public class IgnoredClassTest {

    @Test
    public void ignoredAsPartOfTheIgnoredClassTest() {
    }

}
