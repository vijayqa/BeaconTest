package io.qameta.allure.testng.samples;

import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class ClassFixturesInParent extends ClassFixturesInherited {

    @Test
    public void classFixturesInParent() throws Exception {
    }
}
