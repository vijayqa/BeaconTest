package io.qameta.allure.testng.samples;

import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class CyrillicDescriptions {

    @Test(description = "Тест с описанием на русском языке")
    public void testWithCyrillicDescription() throws Exception {
    }
}
