package io.qameta.allure.testng.samples;

/**
 * @author charlie (Dmitry Baev).
 */
public class BaseTestA extends BaseTest {

    @Override
    void check() {
    }
}
