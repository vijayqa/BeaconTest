package io.qameta.allure.testng.samples;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class ClassFixtures1 {

    @BeforeClass
    public void beforeClass1() throws Exception {
    }

    @Test
    public void classFixtures1() throws Exception {
    }

    @AfterClass
    public void afterClass1() throws Exception {

    }
}
