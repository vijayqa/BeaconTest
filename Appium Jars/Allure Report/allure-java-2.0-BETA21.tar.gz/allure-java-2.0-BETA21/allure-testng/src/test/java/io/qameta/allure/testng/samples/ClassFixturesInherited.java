package io.qameta.allure.testng.samples;

import org.testng.annotations.BeforeClass;

/**
 * @author charlie (Dmitry Baev).
 */
public class ClassFixturesInherited {

    @BeforeClass
    public void beforeClass3() throws Exception {
    }
}
