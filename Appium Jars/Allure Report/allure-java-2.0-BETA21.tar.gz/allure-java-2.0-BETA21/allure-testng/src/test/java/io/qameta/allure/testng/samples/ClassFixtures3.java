package io.qameta.allure.testng.samples;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class ClassFixtures3 {

    @BeforeClass
    public void beforeClass3() throws Exception {
    }

    @Test
    public void classFixtures3() throws Exception {
    }

    @AfterClass
    public void afterClass3() throws Exception {
    }
}
