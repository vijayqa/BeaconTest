package io.qameta.allure.testng.samples;

import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class JustTest {

    @Test
    public void shouldTest() throws Exception {
    }

}
