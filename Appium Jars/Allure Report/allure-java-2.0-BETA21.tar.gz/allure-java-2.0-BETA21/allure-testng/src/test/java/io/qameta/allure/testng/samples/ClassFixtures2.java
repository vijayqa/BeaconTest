package io.qameta.allure.testng.samples;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * @author charlie (Dmitry Baev).
 */
public class ClassFixtures2 {

    @BeforeClass
    public void beforeClass2() throws Exception {
    }

    @Test
    public void classFixtures2() throws Exception {
    }

    @AfterClass
    public void afterClass2() throws Exception {

    }
}
